import sqlite3
from flask import g
import os

DATABASE = 'secure_login.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def init_db(app):
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    get_db().commit()
    return (rv[0] if rv else None) if one else rv

# User Operations
def create_user(username, email, password_hash):
    query_db(
        'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
        (username, email, password_hash)
    )

def get_user_by_username(username):
    return query_db('SELECT * FROM users WHERE username = ?', (username,), one=True)

def get_user_by_email(email):
    return query_db('SELECT * FROM users WHERE email = ?', (email,), one=True)

def get_user_by_id(user_id):
    return query_db('SELECT * FROM users WHERE id = ?', (user_id,), one=True)

def set_2fa_secret(user_id, secret):
    query_db('UPDATE users SET two_factor_secret = ? WHERE id = ?', (secret, user_id))

# Activity Logging
def log_activity(user_id, ip_address, status):
    query_db(
        'INSERT INTO activity_logs (user_id, ip_address, status) VALUES (?, ?, ?)',
        (user_id, ip_address, status)
    )

def get_recent_activity(user_id, limit=5):
    return query_db(
        'SELECT * FROM activity_logs WHERE user_id = ? ORDER BY login_time DESC LIMIT ?',
        (user_id, limit)
    )
