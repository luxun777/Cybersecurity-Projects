import os
from flask import Flask, render_template, request, redirect, url_for, flash, session, g
import bcrypt
import pyotp
import qrcode
from io import BytesIO
import base64
from dotenv import load_dotenv
import re
from email_validator import validate_email, EmailNotValidError

from database import init_db, get_db, create_user, get_user_by_username, get_user_by_email, get_user_by_id, log_activity, get_recent_activity, set_2fa_secret

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'fallback-secret-key-do-not-use-in-prod')

# Teardown DB connection
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Validation Helpers
def is_strong_password(password):
    # At least 8 chars, 1 uppercase, 1 lowercase, 1 digit, 1 special char
    if len(password) < 8: return False
    if not re.search(r"[A-Z]", password): return False
    if not re.search(r"[a-z]", password): return False
    if not re.search(r"\d", password): return False
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password): return False
    return True

# Decorator for protected routes
from functools import wraps
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Ensure DB is initialized (useful for first run)
with app.app_context():
    if not os.path.exists('secure_login.db'):
        init_db(app)

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        # Basic Validation
        if not username or not email or not password or not confirm_password:
            flash('All fields are required.', 'error')
            return render_template('register.html')

        if len(username) < 3 or len(username) > 20:
            flash('Username must be between 3 and 20 characters.', 'error')
            return render_template('register.html')

        # Email Validation
        try:
            valid = validate_email(email)
            email = valid.email
        except EmailNotValidError as e:
            flash(str(e), 'error')
            return render_template('register.html')

        # Password Validation
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('register.html')
        
        if not is_strong_password(password):
            flash('Password must be at least 8 characters long, contain an uppercase letter, a lowercase letter, a number, and a special character.', 'error')
            return render_template('register.html')

        # Check existing user
        if get_user_by_username(username):
            flash('Username already exists.', 'error')
            return render_template('register.html')
        
        if get_user_by_email(email):
            flash('Email already registered.', 'error')
            return render_template('register.html')

        # Hash password and create user
        salt = bcrypt.gensalt()
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

        create_user(username, email, hashed_password)
        
        # Log successful registration implicitly by telling them to login
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        ip_address = request.remote_addr

        if not username or not password:
            flash('Please enter both username and password.', 'error')
            return render_template('login.html')

        user = get_user_by_username(username)

        if user and bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
            # Successful login logic
            session.clear() # Clear existing session data just in case
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            
            log_activity(user['id'], ip_address, 'SUCCESS')
            flash('Successfully logged in.', 'success')
            return redirect(url_for('dashboard'))
        else:
            # Failed login
            if user:
                log_activity(user['id'], ip_address, 'FAILED')
            flash('Invalid username or password.', 'error')
            return render_template('login.html')

    return render_template('login.html')

@app.route('/logout')
def logout():
    if 'user_id' in session:
        log_activity(session['user_id'], request.remote_addr, 'LOGOUT')
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    user = get_user_by_id(session['user_id'])
    recent_activity = get_recent_activity(session['user_id'], limit=5)
    return render_template('dashboard.html', user=user, activity=recent_activity)

# Optional 2FA Routes (Skeleton/Implementation)
@app.route('/setup-2fa')
@login_required
def setup_2fa():
    user = get_user_by_id(session['user_id'])
    if user['two_factor_secret']:
        flash('2FA is already set up.', 'info')
        return redirect(url_for('dashboard'))

    secret = pyotp.random_base32()
    set_2fa_secret(user['id'], secret)

    # Generate QR code
    totp = pyotp.TOTP(secret)
    provisioning_uri = totp.provisioning_uri(name=user['email'], issuer_name="CyberAuth")
    
    img = qrcode.make(provisioning_uri)
    buffered = BytesIO()
    img.save(buffered)
    img_str = base64.b64encode(buffered.getvalue()).decode()

    return render_template('2fa_setup.html', qr_code=img_str, secret=secret)


if __name__ == '__main__':
    # Running in debug mode for development
    app.run(debug=True, port=5099, host='0.0.0.0')
