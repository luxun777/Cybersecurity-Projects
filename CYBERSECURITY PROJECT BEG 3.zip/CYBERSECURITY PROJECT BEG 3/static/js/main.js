document.addEventListener('DOMContentLoaded', () => {
    // Password Strength Meter
    const passwordInput = document.getElementById('password');
    const strengthBar = document.getElementById('strength-bar');
    const strengthText = document.getElementById('strength-text');

    if (passwordInput && strengthBar) {
        passwordInput.addEventListener('input', () => {
            const val = passwordInput.value;
            let strength = 0;
            let status = '';
            let color = '';

            if (val.length > 0) {
                if (val.length >= 8) strength += 1;
                if (val.match(/[A-Z]/)) strength += 1;
                if (val.match(/[a-z]/)) strength += 1;
                if (val.match(/[0-9]/)) strength += 1;
                if (val.match(/[^a-zA-Z0-9]/)) strength += 1;

                switch (strength) {
                    case 1:
                    case 2:
                        status = 'Weak';
                        color = '#ef4444'; // red
                        strengthBar.style.width = '33%';
                        break;
                    case 3:
                    case 4:
                        status = 'Medium';
                        color = '#eab308'; // yellow
                        strengthBar.style.width = '66%';
                        break;
                    case 5:
                        status = 'Strong';
                        color = '#10b981'; // green
                        strengthBar.style.width = '100%';
                        break;
                }
            } else {
                strengthBar.style.width = '0%';
                status = '';
            }

            strengthBar.style.backgroundColor = color;
            if(strengthText) {
                strengthText.textContent = status;
                strengthText.style.color = color;
            }
        });
    }

    // Toggle Password Visibility
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    togglePasswordButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const input = document.getElementById(targetId);
            const icon = this.querySelector('i');

            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });

    // Auto-hide flash messages after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    if (alerts.length > 0) {
        setTimeout(() => {
            alerts.forEach(alert => {
                alert.style.transition = 'opacity 0.5s ease';
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 500);
            });
        }, 5000);
    }
});
