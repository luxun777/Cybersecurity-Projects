# Secure Login System

A professional, enterprise-grade authentication system built with Python Flask, demonstrating modern web security best practices and featuring a dark, cybersecurity-themed UI.

## Features

*   **Robust User Registration:** Input validation for emails, strong password enforcement, and secure storage.
*   **Secure Authentication:** Passwords hashed using `bcrypt` to protect against data breaches.
*   **SQL Injection Protection:** Database interactions are secured using parameterized queries (`sqlite3`).
*   **Session Management:** Secure HTTP-only cookies to manage user sessions and protect dashboard routes.
*   **Activity Logging:** Tracks successful logins, failed attempts, and logouts with IP logging.
*   **Modern UI:** A dark, "glassmorphism" interface with neon blue accents, designed for a premium cybersecurity SaaS feel.
*   **Responsive Layout:** Fully accessible and usable on mobile and desktop devices.

## Technologies Used

*   **Backend:** Python 3, Flask
*   **Database:** SQLite (with explicit parameterized queries for security)
*   **Security & Hashing:** `bcrypt`, `pyotp` (ready for 2FA), `email_validator`
*   **Frontend:** HTML5, CSS3 (Custom Glassmorphism Design), Vanilla JavaScript
*   **Icons:** FontAwesome

## Security Features Demonstrated

1.  **Password Hashing:** Passwords are never stored in plain text. `bcrypt` handles salting and hashing.
2.  **SQL Injection Prevention:** Avoided string formatting for SQL queries. All queries use the `?` placeholder method provided by SQLite.
3.  **Cross-Site Request Forgery (CSRF) & Session Security:** Flask's built-in secure cookie management is utilized. (A full CSRF token implementation can be added via `Flask-WTF` for further hardening).
4.  **Input Sanitization & Validation:** Server-side validation using regular expressions and the `email_validator` library ensures only clean data reaches the database. Client-side validation is included for immediate user feedback.

## Installation Steps

1.  **Clone the repository** (or navigate to the project directory).
    ```bash
    cd "CYBERSECURITY PROJECT BEG 3"
    ```

2.  **Create a virtual environment** (recommended):
    ```bash
    python -m venv venv
    # Activate on Windows:
    venv\Scripts\activate
    # Activate on macOS/Linux:
    source venv/bin/activate
    ```

3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Run the application:**
    ```bash
    python app.py
    ```
    *Note: The database (`secure_login.db`) will be automatically created and initialized on the first run.*

5.  **Access the application:**
    Open a web browser and go to `http://127.0.0.1:5000/`.

## Authentication Workflow

1.  **Registration:** The user submits a username, email, and strong password. The backend validates the inputs. The password is hashed with a random salt via `bcrypt`. Data is saved via parameterized SQL.
2.  **Login:** The user submits credentials. The backend queries the database by username. If found, `bcrypt.checkpw()` compares the provided password with the stored hash.
3.  **Session Creation:** Upon success, a secure Flask session is established, and the user's ID is stored in the encrypted session cookie.
4.  **Access Control:** The `@login_required` decorator checks for a valid session before rendering dashboard pages.
5.  **Logging:** Every login attempt (success or failure) and logout action is recorded in the `activity_logs` table.

## Future Improvements

*   Implement the optional 2FA (Google Authenticator) flow (routes and setup logic are partially stubbed).
*   Add email verification via SMTP.
*   Implement account lockout after `N` failed login attempts.
*   Add password reset functionality via secure email links.
